import { CircularProgress, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material'
import axios from 'axios'
import React, { useEffect, useState } from 'react'

const Viewdata = () => {
    var [users,setUsers]= useState([]) 
    var [loading,SetLoading] = useState(false)

    useEffect(()=>{
        SetLoading(true)
        axios.get("https://jsonplaceholder.typicode.com/posts")
        .then((res)=>{
    console.log(res)
    setUsers(res.data)
    SetLoading(false)
    })
    .catch(err=>console.log(err))
    },[])
  return (
    <div style ={{paddingTop:"80px"}}>
   

    {loading? <CircularProgress color='primary'/>: <TableContainer>
<Table>
   <TableHead>
       <TableRow>
   <TableCell>Name</TableCell>
   <TableCell>Description</TableCell>
   <TableCell>Author Name</TableCell>
       </TableRow>
   </TableHead>
   <TableBody>
       {users.map((val,i)=>{
           return(
               <TableRow><TableCell>{val.id}</TableCell>
               <TableCell>{val.title}</TableCell>
               <TableCell>{val.body}</TableCell>
              
               </TableRow>
           )
       })}

   </TableBody>
</Table>
</TableContainer>}</div>
  )
}

export default Viewdata